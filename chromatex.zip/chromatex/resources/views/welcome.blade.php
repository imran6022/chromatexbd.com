<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Chromatex BD</title>
        <link rel="stylesheet" href="{{ asset ('css/bootstrap.min.css') }}">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/custom.css') }}">

        <!-- Styles -->
        
    </head>
    <body>
        <div class="container">
      <div class="header">
        <div class="menu">
          <nav class="navbar navbar-expand-lg fixed-top container">
            <a class="navbar-brand" href="#">
              <!-- <img src="{{ asset('images/tex-bd.png') }}"> -->
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="#home">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#product1">Features</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#washing">Washing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#dyeing">Dyeing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#chemical">Chemical</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Supplier">Supplier</a>
                </li>
                
                <!--<li class="nav-item dropdown">-->
                <!--  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">-->
                <!--    Products-->
                <!--  </a>-->
                <!--  <div class="dropdown-menu" aria-labelledby="navbarDropdown">-->
                <!--    <a class="dropdown-item" href="#"></a>-->
                <!--    <a class="dropdown-item" href="#">Dyeing</a>-->
                <!--    <a class="dropdown-item" href="#chemical">Chemicals</a>-->
                <!--    <a class="dropdown-item" href="#">Dyeing</a>-->
                <!--</li>-->
                <li class="nav-item">
                  <a class="nav-link" href="#contact">Contact</a>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        <div class="slider">
          <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block w-100" src="{{ asset('images/slider/slider3.jpg')}}" alt="First slide">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="{{ asset('images/slider/slider1.jpg')}}" alt="Second slide">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="{{ asset('images/slider/slider3.jpg')}}" alt="Third slide">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
      </div>

      <div class="main-body">
        <section id="home">
          <div class="row">
              <div class="col">
                  <img src="./images/about.png" alt="Image" width="100%">
              </div>
           </div>
         </section>
         
         <section id="product1">
          <div class="row">
              <div class="col">
                  <img src="./images/product1.png" alt="Image" width="100%">
              </div>
           </div>
         </section>

         <section id="washing">
          <div class="row">
            <div class="col">
              <img src="./images/product2.png" alt="Washing Img" width="100%" >
            </div>
            </div>
         </section>

         <section id="dyeing">
          <div class="row">
            <div class="col">
              <img src="./images/product3.png" alt="Washing Img" width="100%" >
            </div>
            </div>
         </section>

         <section id="chemical">
          <div class="row">
            <div class="col">
              <img src="./images/product.png" alt="Washing Img" width="100%" >
            </div>
          </div>
         </section>
         
         <section id="Supplier">
          <div class="row">
            <div class="col">
              <img src="./images/raas.png" alt="Washing Img" width="100%" >
            </div>
          </div>
         </section>

         <section id="contact">
          <div class="row">
            <div class="col">
              <img src="./images/contact1.png" alt="Washing Img" width="100%" >
            </div>
          </div>
         </section>
      </div>

    </div>

     <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
</html>
